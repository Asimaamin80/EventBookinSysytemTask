// import { arValidation } from './ar-validation'
import { enValidation } from './en-validation'

export const validation = () => {
    return enValidation;
}