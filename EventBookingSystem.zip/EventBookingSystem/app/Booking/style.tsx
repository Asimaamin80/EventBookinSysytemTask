import {StyleSheet} from 'react-native';
import {getFontSize, getHeight, getWidth} from './../../utils/ResponsiveFun';

export const styles = StyleSheet.create({
  contaner: {
    alignItems: 'center',
    flex: 1,},
  


});